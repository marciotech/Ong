package org.ong.ongforblacklives;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OngForBlackLivesApplicationTests {

	@Test
	void contextLoads() {
	}

}
